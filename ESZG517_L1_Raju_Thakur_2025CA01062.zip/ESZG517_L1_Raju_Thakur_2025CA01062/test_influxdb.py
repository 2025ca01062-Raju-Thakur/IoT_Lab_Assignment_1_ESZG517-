from influxdb_client import InfluxDBClient, Point
from influxdb_client.client.write_api import SYNCHRONOUS

URL = "https://us-east-1-1.aws.cloud2.influxdata.com"

TOKEN = "a3l3L09yXqI0EEjuTCzgzGdWHjavbQK_Ps8LaPvHiwyhe628xxiQl6OZEq4lCykSV--h_AsBtxAfgSCHmO8o1Q=="

ORG = "Faculty - IOT"

BUCKET = "iotlab"

client = InfluxDBClient(
    url=URL,
    token=TOKEN,
    org=ORG
)

write_api = client.write_api(write_options=SYNCHRONOUS)

try:
    point = Point("connection_test").field("value", 1)

    write_api.write(
        bucket=BUCKET,
        org=ORG,
        record=point
    )

    print("SUCCESS")

except Exception as e:
    print(e)

finally:
    client.close()
